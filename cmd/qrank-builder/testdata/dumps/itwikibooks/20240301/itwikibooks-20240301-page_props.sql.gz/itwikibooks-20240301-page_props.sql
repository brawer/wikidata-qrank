-- SPDX-FileCopyrightText: 2024 Sascha Brawer <sascha@brawer.ch>
-- SPDX-License-Identifier: CC0-1.0

DROP TABLE IF EXISTS `page_props`;

CREATE TABLE `page_props` (
  `pp_page` int(10) unsigned NOT NULL,
  `pp_propname` varbinary(60) NOT NULL DEFAULT '',
  `pp_value` blob NOT NULL,
  `pp_sortkey` float DEFAULT NULL,
  PRIMARY KEY (`pp_page`,`pp_propname`),
  UNIQUE KEY `pp_propname_page` (`pp_propname`,`pp_page`),
  UNIQUE KEY `pp_propname_sortkey_page` (`pp_propname`,`pp_sortkey`,`pp_page`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;

INSERT INTO `page_props` VALUES
  (54321,'wikibase_item','Q54321',NULL),
  (54322,'wikibase_item','Q54322',NULL),
  (123456,'wikibase_item','Q8681970',NULL);

