-- SPDX-FileCopyrightText: 2024 Sascha Brawer <sascha@brawer.ch>
-- SPDX-License-Identifier: MIT
--
-- This table has no pl_title or pl_namespace column. Instead,
-- it uses pl_target_id as a foreign key for linktarget.
--
-- https://github.com/brawer/wikidata-qrank/issues/43
-- https://www.mediawiki.org/wiki/Manual:Linktarget_table

DROP TABLE IF EXISTS `pagelinks`;
CREATE TABLE `pagelinks` (
  `pl_from` int(8) unsigned NOT NULL DEFAULT 0,
  `pl_from_namespace` int(11) NOT NULL DEFAULT 0,
  `pl_target_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`pl_from`,`pl_target_id`),
  KEY `pl_target_id` (`pl_target_id`,`pl_from`),
  KEY `pl_backlinks_namespace_target_id` (`pl_from_namespace`,`pl_target_id`,`pl_from`)
);

INSERT INTO `pagelinks` VALUES
  (1768,1,301),
  (123456,0,374),
  (123456,0,375);
