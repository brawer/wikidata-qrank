-- SPDX-FileCopyrightText: 2022 Sascha Brawer <sascha@brawer.ch>
-- SPDX-License-Identifier: MIT

DROP TABLE IF EXISTS `page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page` (
  `page_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_namespace` int(11) NOT NULL,
  `page_title` varbinary(255) NOT NULL,
  `page_is_redirect` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `page_is_new` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `page_random` double unsigned NOT NULL,
  `page_touched` binary(14) NOT NULL,
  `page_links_updated` varbinary(14) DEFAULT NULL,
  `page_latest` int(10) unsigned NOT NULL,
  `page_len` int(10) unsigned NOT NULL,
  `page_content_model` varbinary(32) DEFAULT NULL,
  `page_lang` varbinary(35) DEFAULT NULL,
  PRIMARY KEY (`page_id`),
  UNIQUE KEY `page_name_title` (`page_namespace`,`page_title`),
  KEY `page_random` (`page_random`),
  KEY `page_len` (`page_len`),
  KEY `page_redirect_namespace_len` (`page_is_redirect`,`page_namespace`,`page_len`)
) ENGINE=InnoDB AUTO_INCREMENT=119420819 DEFAULT CHARSET=binary ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page`
--

/*!40000 ALTER TABLE `page` DISABLE KEYS */;
INSERT INTO `page` VALUES
  (1,4,'Pagina_principala',0,0,0.622781966637,'20240126184925','20240126185337',159146,2500,'wikitext',NULL),
  (799,0,'Turitg',0,0,0.979846056347,'20240221070919','20240221070956',161037,3142,'wikitext',NULL),
  (811,0,'Main_Page',1,0,0.923690063506,'20230606232400','20230606232400',101950,41,'wikitext',NULL),
  (3824,0,'Obergesteln',0,0,0.497650023341,'20230313054021','20230313054114',163633,4973,'wikitext',NULL),
  (4108,0,'Zürich',1,1,0.262244319829,'20230606234048','20230606234048',15557,20,'wikitext',NULL),
  (6857,2,'Username',1,1,0.780168818562,'20230607000731','20230607000731',34654,32,'wikitext',NULL),
  (14564,10,'Pajais_Federativ_Austria',0,0,0.30711200806,'20240201215517','20240128220014',165139,916,'wikitext',NULL);
