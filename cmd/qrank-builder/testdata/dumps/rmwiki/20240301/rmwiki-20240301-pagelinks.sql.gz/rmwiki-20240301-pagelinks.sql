-- SPDX-FileCopyrightText: 2024 Sascha Brawer <sascha@brawer.ch>
-- SPDX-License-Identifier: MIT

--
-- Table structure for table `pagelinks`
--

DROP TABLE IF EXISTS `pagelinks`;
CREATE TABLE `pagelinks` (
  `pl_from` int(8) unsigned NOT NULL DEFAULT 0,
  `pl_namespace` int(11) NOT NULL DEFAULT 0,
  `pl_title` varbinary(255) NOT NULL DEFAULT '',
  `pl_from_namespace` int(11) NOT NULL DEFAULT 0,
  `pl_target_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`pl_from`,`pl_target_id`),
  KEY `pl_namespace` (`pl_namespace`,`pl_title`,`pl_from`),
  KEY `pl_backlinks_namespace` (`pl_from_namespace`,`pl_namespace`,`pl_title`,`pl_from`),
  KEY `pl_target_id` (`pl_target_id`,`pl_from`),
  KEY `pl_backlinks_namespace_target_id` (`pl_from_namespace`,`pl_target_id`,`pl_from`)
) ENGINE=InnoDB DEFAULT CHARSET=binary ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;

--
-- Dumping data for table `pagelinks`
--

INSERT INTO `pagelinks` VALUES
  (1,4,'Bainvegni',4,1394),
  (3824,0,'Zürich',0,2085),
  (4689,0,'1._avuost',0,10541),
  (799,0,'Chantun_Turitg',0,1686),
  (799,0,'Flum',0,2034),
  (799,0,'Lai_da_Turitg',0,1820),
  (799,0,'Limmat',0,2036),
  (14564,0,'Austria',10,1633),
  (14564,10,'Pajais_Federativ_Austria',10,33275);
