-- SPDX-FileCopyrightText: 2022 Sascha Brawer <sascha@brawer.ch>
-- SPDX-License-Identifier: MIT

--
-- Table structure for table `iwlinks`
--

DROP TABLE IF EXISTS `iwlinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iwlinks` (
  `iwl_from` int(10) unsigned NOT NULL DEFAULT 0,
  `iwl_prefix` varbinary(32) NOT NULL DEFAULT '',
  `iwl_title` varbinary(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`iwl_from`,`iwl_prefix`,`iwl_title`),
  KEY `iwl_prefix_title_from` (`iwl_prefix`,`iwl_title`,`iwl_from`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iwlinks`
--

/*!40000 ALTER TABLE `iwlinks` DISABLE KEYS */;
INSERT INTO `iwlinks` VALUES
  (1,'d','Wikidata:Accueil_principal'),
  (1,'m','Hauptseite'),
  (1,'meta','Lista_di_Wikipedie'),
  (1,'s','Main_Page/Rumantsch'),
  (1,'s','it:Categoria:Testi_in_romancio'),
  (1,'translatewiki','Portal:rm'),
  (1,'wikispecies','Hauptseite'),
  (799,'de','gsw:User:Test');
