-- SPDX-FileCopyrightText: 2022 Sascha Brawer <sascha@brawer.ch>
-- SPDX-License-Identifier: MIT

DROP TABLE IF EXISTS `page_props`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_props` (
  `pp_page` int(10) unsigned NOT NULL,
  `pp_propname` varbinary(60) NOT NULL DEFAULT '',
  `pp_value` blob NOT NULL,
  `pp_sortkey` float DEFAULT NULL,
  PRIMARY KEY (`pp_page`,`pp_propname`),
  UNIQUE KEY `pp_propname_page` (`pp_propname`,`pp_page`),
  UNIQUE KEY `pp_propname_sortkey_page` (`pp_propname`,`pp_sortkey`,`pp_page`)
) ENGINE=InnoDB DEFAULT CHARSET=binary;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_props`
--
INSERT INTO `page_props` VALUES
  (1,'translate-has-languages-tag','1',1),
  (1,'wikibase_item','Q107661323',NULL),

  (200,'kartographer_frames','1',1),
  (200,'page_image_free','Zuerich_Fraumuenster_St_Peter.jpg',NULL),
  (200,'wb-claims','550',550),
  (200,'wb-identifiers','85',85),
  (200,'wb-sitelinks','186',186),

  (623646,'kartographer_frames','1',1),
  (623646,'page_image_free','Obergesteln2.JPG',NULL),
  (623646,'wb-claims','32',32),
  (623646,'wb-identifiers','9',9),
  (623646,'wb-sitelinks','15',15),

  (5411171,'wb-claims','1',1),
  (5411171,'wb-identifiers','0',0),
  (5411171,'wb-sitelinks','20',20),

  (19441465,'wikibase_item','Q5296',NULL);
