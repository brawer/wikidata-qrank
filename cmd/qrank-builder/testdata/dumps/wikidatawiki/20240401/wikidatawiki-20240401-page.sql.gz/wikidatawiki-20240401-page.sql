-- SPDX-FileCopyrightText: 2022 Sascha Brawer <sascha@brawer.ch>
-- SPDX-License-Identifier: MIT

DROP TABLE IF EXISTS `page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page` (
  `page_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_namespace` int(11) NOT NULL,
  `page_title` varbinary(255) NOT NULL,
  `page_is_redirect` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `page_is_new` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `page_random` double unsigned NOT NULL,
  `page_touched` binary(14) NOT NULL,
  `page_links_updated` varbinary(14) DEFAULT NULL,
  `page_latest` int(10) unsigned NOT NULL,
  `page_len` int(10) unsigned NOT NULL,
  `page_content_model` varbinary(32) DEFAULT NULL,
  `page_lang` varbinary(35) DEFAULT NULL,
  PRIMARY KEY (`page_id`),
  UNIQUE KEY `page_name_title` (`page_namespace`,`page_title`),
  KEY `page_random` (`page_random`),
  KEY `page_len` (`page_len`),
  KEY `page_redirect_namespace_len` (`page_is_redirect`,`page_namespace`,`page_len`)
) ENGINE=InnoDB AUTO_INCREMENT=119420819 DEFAULT CHARSET=binary ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page`
--

/*!40000 ALTER TABLE `page` DISABLE KEYS */;
INSERT INTO `page` VALUES
  (1,4,'Main_Page/Content',0,0,0.855317949554,'20240402204829','20240402204836',2103190580,3470,'wikitext',NULL),
  (200,0,'Q72',0,0,0.461502919613,'20240402193245','20240402193245',2117670436,830167,'wikibase-item',NULL),
  (623646,0,'Q662541',0,0,0.880219514988,'20240325100534','20240325100534',2110364302,29215,'wikibase-item',NULL),
  (5411171,0,'Q5649951',0,0,0.463961949475,'20230924194349','20230924194349',1980936027,25022,'wikibase-item',NULL),
  (19441465,4,'Main_Page',0,0,0.125705881927,'20240402204829','20240402204836',1816946465,372,'wikitext','en');
