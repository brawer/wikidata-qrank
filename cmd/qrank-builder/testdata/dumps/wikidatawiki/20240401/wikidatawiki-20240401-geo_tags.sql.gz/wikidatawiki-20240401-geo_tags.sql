-- SPDX-FileCopyrightText: 2026 Sascha Brawer <sascha@brawer.ch>
-- SPDX-License-Identifier: MIT

DROP TABLE IF EXISTS `geo_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `geo_tags` (
  `gt_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gt_page_id` int(10) unsigned NOT NULL,
  `gt_globe` varbinary(32) NOT NULL,
  `gt_primary` tinyint(1) NOT NULL,
  `gt_lat` decimal(11,8) DEFAULT NULL,
  `gt_lon` decimal(11,8) DEFAULT NULL,
  `gt_dim` int(11) DEFAULT NULL,
  `gt_type` varbinary(32) DEFAULT NULL,
  `gt_name` varbinary(255) DEFAULT NULL,
  `gt_country` binary(2) DEFAULT NULL,
  `gt_region` varbinary(3) DEFAULT NULL,
  `gt_lat_int` smallint(6) DEFAULT NULL,
  `gt_lon_int` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`gt_id`),
  KEY `gt_page_primary` (`gt_page_id`,`gt_primary`),
  KEY `gt_page_id_id` (`gt_page_id`,`gt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16936803 DEFAULT CHARSET=binary ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geo_tags`
--

LOCK TABLES `geo_tags` WRITE;
/*!40000 ALTER TABLE `geo_tags` DISABLE KEYS */;
INSERT INTO `geo_tags` VALUES
(1,200,'earth',1,47.37444444,8.54111111,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(2,200,'earth',0,47.28000000,8.40000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(3,623646,'moon',1,47.37444444,8.54111111,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4,623646,'earth',1,46.51000000,8.31000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(5,5411171,'earth',1,89.90000000,0.00000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(6,99,'earth',1,47.37444444,8.54111111,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(7,1,'earth',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `geo_tags` ENABLE KEYS */;
UNLOCK TABLES;
